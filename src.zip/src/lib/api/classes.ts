// src/lib/api/classes.ts

import { Class } from '@/types/lesson';

export async function getEnrolledClasses(): Promise<Class[]> {
    try {
        const response = await fetch('/api/classes/enrolled', {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
            },
            credentials: 'include',
            // Impede o cache para sempre pegar os dados mais recentes
            cache: 'no-store'
        });

        if (!response.ok) {
            throw new Error('Failed to fetch enrolled classes');
        }

        const data = await response.json();
        return data;
    } catch (error) {
        console.error('Error fetching enrolled classes:', error);
        // Em caso de erro, retorna array vazio para não quebrar a UI
        return [];
    }
}