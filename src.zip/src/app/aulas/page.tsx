// src/app/aulas/page.tsx
import { getEnrolledClasses } from '@/lib/api/classes';
import CurrentLessonBar from '@/components/class/CurrentLessonBar';
import LessonsContent from '@/app/aulas/LessonsContent';

export default async function LessonsPage() {
    const enrolledClasses = await getEnrolledClasses();
    const processedClasses = enrolledClasses.map(classItem => ({
        ...classItem,
        latestLesson: classItem.lessons?.[0] || undefined
    }));

    return (
        <div className="flex flex-col min-h-screen">
            {processedClasses.length > 0 && (
                <CurrentLessonBar enrolledClasses={processedClasses} />
            )}
            <LessonsContent />
        </div>
    );
}