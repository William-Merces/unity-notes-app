// src/app/page.tsx

import ClassList from '@/components/class/ClassList';
import CurrentLessonBar from '@/components/class/CurrentLessonBar';
import { getEnrolledClasses } from '@/lib/api/classes';

export default async function Home() {
    try {
        const enrolledClasses = await getEnrolledClasses();
        console.log('Enrolled Classes:', enrolledClasses); // Debug log

        // Garante que temos os dados necessários
        const processedClasses = enrolledClasses.map(classItem => ({
            ...classItem,
            latestLesson: classItem.lessons?.[0] ? { id: classItem.lessons[0].id, title: classItem.lessons[0].title } : undefined
        }));

        return (
            <div className="flex flex-col min-h-screen">
                {processedClasses.length > 0 && (
                    <div className="w-full">
                        <CurrentLessonBar 
                            enrolledClasses={processedClasses.filter(c => c.latestLesson)} 
                        />
                    </div>
                )}
                <main className="flex-1 p-4">
                    <div className="w-full max-w-4xl mx-auto">
                        <h1 className="text-2xl font-bold mb-6">Classes Disponíveis</h1>
                        <ClassList mode="available" />
                    </div>
                </main>
            </div>
        );
    } catch (error) {
        console.error('Error in Home page:', error);
        return (
            <main className="min-h-screen p-4">
                <div className="w-full max-w-4xl mx-auto">
                    <h1 className="text-2xl font-bold mb-6">Classes Disponíveis</h1>
                    <ClassList mode="available" />
                </div>
            </main>
        );
    }
}