// src/app/api/classes/enrolled/route.ts

import { NextResponse } from 'next/server';
import { verifyToken } from '@/lib/auth';
import { prisma } from '@/lib/prisma';

export async function GET() {
    try {
        const user = await verifyToken();
        if (!user) {
            return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
        }

        console.log('Fetching enrolled classes for user:', user.id); // Debug log

        const enrolledClasses = await prisma.class.findMany({
            where: {
                enrollments: {
                    some: {
                        userId: user.id,
                        status: 'ACTIVE'
                    }
                }
            },
            include: {
                ward: {
                    include: {
                        stake: true
                    }
                },
                _count: {
                    select: {
                        enrollments: true
                    }
                },
                lessons: {
                    where: {
                        isActive: true
                    },
                    orderBy: {
                        createdAt: 'desc'
                    },
                    take: 1,
                    select: {
                        id: true,
                        title: true,
                        isActive: true,
                        currentSlide: true,
                        createdAt: true,
                        updatedAt: true,
                        class: {
                            select: {
                                id: true,
                                name: true
                            }
                        }
                    }
                }
            },
            orderBy: {
                name: 'asc'
            }
        });

        console.log('Found enrolled classes:', JSON.stringify(enrolledClasses, null, 2)); // Debug log

        // Estrutura os dados para garantir o formato correto
        const formattedClasses = enrolledClasses.map(classItem => ({
            ...classItem,
            latestLesson: classItem.lessons?.[0] || null
        }));

        return NextResponse.json(formattedClasses);
    } catch (error) {
        console.error('Error in GET /api/classes/enrolled:', error);
        return NextResponse.json(
            { error: 'Failed to fetch enrolled classes', details: error instanceof Error ? error.message : 'Unknown error' },
            { status: 500 }
        );
    }
}